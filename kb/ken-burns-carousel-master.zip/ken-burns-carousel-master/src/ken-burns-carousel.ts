import Carousel from './element.js';

customElements.define('ken-burns-carousel', Carousel);

export default Carousel;
